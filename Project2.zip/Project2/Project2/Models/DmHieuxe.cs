﻿using System;
using System.Collections.Generic;

namespace Project2.Models;

public partial class DmHieuxe
{
    public int PrKey { get; set; }

    public string HieuXe { get; set; } = null!;
}
